from win32com import client as wc
import os
from docx import Document
from docx.shared import Inches
import re

originPath = "D:\\program\\wordparse\\files\\"

targetPath = "D:\\program\\wordparse\\filesT\\"

words = "财务报表审计"

# make a new file

# step1 transfer .doc to .docx
word = wc.Dispatch("Word.Application")

def transferFile(dir):
    filename = dir.replace(originPath, '').split('.')[0]
    doc = word.Documents.Open(dir)
    doc.SaveAs(targetPath + filename + '.docx', 12)
    doc.Close()

# read all files in directory
def eachFile(filepath):
    pathDir = os.listdir(filepath)
    for allDir in pathDir:
        child = os.path.join('%s%s' % (filepath, allDir))
        transferFile(child)
        # print(child)
    word.Quit()


eachFile(originPath)




